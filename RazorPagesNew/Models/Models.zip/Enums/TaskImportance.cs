﻿namespace RazorPagesNew.Models.Enums
{
    /// <summary>
    /// Важность задачи
    /// </summary>
    public enum TaskImportance
    {
        Low,
        Medium,
        High,
        Critical
    }
}
